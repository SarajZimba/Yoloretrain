# Face Detection > 2025-01-08 11:35am
https://universe.roboflow.com/silverlinetester/face-detection-xmnwd

Provided by a Roboflow user
License: CC BY 4.0

